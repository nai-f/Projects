#!/bin/python3
import re

ip1 = "192.168.100.1"
ip2 = "192.168.100.2"
ip3 = "192.168.200.1"
ip4 = "192.168.200.2"
ips = [ip1,ip2,ip3,ip4]
def compute_size_metrics(data, ip):
    reqSent = 0
    reqReceived = 0
    replSent = 0
    replReceived = 0
    reqBytesSent = 0
    reqBytesReceived = 0
    reqDataSent = 0
    reqDataReceived = 0

    #get quantity data
    for packet in data:
        if packet[2] == ip and "request" in packet:
            reqSent += 1
            reqBytesSent += float(packet[5])
        elif packet[2] == ip and "reply" in packet:
            replSent += 1
            reqBytesReceived += float(packet[5])
        elif "request" in packet:
            reqReceived += 1
        elif "reply" in packet:
            replReceived += 1
    reqDataSent = reqBytesSent - (reqSent * 42)
    reqDataReceived = reqBytesReceived - (reqReceived * 42)
    return(reqSent, replSent, reqReceived, replReceived, reqBytesSent, reqBytesReceived, reqDataSent, reqDataReceived)


def compute_distance(data, ip):
    reqSent = 0
    totalHops = 0
    startTtl = 128

    for i, packet in enumerate(data):
        if packet[3] == ip and "reply" in packet:
            reqSent += 1
            fieldString = packet[11]
            ttlMatch = re.search("\d+", fieldString)
            ttl = float(ttlMatch.group(0))
            hops = startTtl - ttl
            totalHops += startTtl - ttl + 1
    
    return round(totalHops / reqSent, 2)

def compute_time(data, ip):
    Ave_RTT = 0
    EchoReqThr = 0
    EchoReqGP = 0
    AveRepDel = 0
    req = 0
    rep = 0
    count = 0
    FrameSize = 0
    ICMP_load = 0
    replyTime = 0
    

    for packet in data:
        #print(packet)
        if packet[2] == ip and "request" in packet:
           req +=  float(packet[1])
           FrameSize += float(packet[5])
           ICMP_load +=(float(packet[5]) - 42)
        if packet[3] == ip and "reply" in packet:           
           rep += float(packet[1])
           count += 1
           replyTime = float(packet[1])
           
           
    Ave_RTT = round(float(((rep - req) / count ) * 1000), 2 )

    EchoReqThr = round((FrameSize / 1000) / (rep - req), 1)
    EchoReqGP = round(((ICMP_load / 1000) / (rep - req)),1)
    AveRepDel = reply_delay(data, ip)
    return (Ave_RTT, EchoReqThr, EchoReqGP, AveRepDel)

def reply_delay(data, ip):
    totalDelayTime = 0
    totalReplyCount = 0
    requestReceived = 0

    for i, packet in enumerate(data):
        if packet[3] == ip and "request" in packet:
            requestReceived = float(packet[1])
        if packet[2] == ip and "reply" in packet:
            delayTime = float(packet[1]) - requestReceived
            totalDelayTime += delayTime
            requestReceived = 0
            totalReplyCount += 1

    return round(totalDelayTime/totalReplyCount * 1000000, 2)
    
    
def compute_metrics(data):
    f = open("output.csv", "w")
    for i, node in enumerate(data):
        nodeNum = i + 1
        size_metrics = compute_size_metrics(node, ips[i])
        time_metrics = compute_time(node, ips[i])
        distance_metric = compute_distance(node, ips[i])
        
        f.write("Node " + str(nodeNum) + "\n\n")
        f.write("Echo Requests Sent,Echo Requests Received,Echo Replies Sent,Echo Replies Received\n")
        f.write(str(size_metrics[0]) + "," + str(size_metrics[1]) + "," + str(size_metrics[2]) + "," + str(size_metrics[3]) + "\n")
        f.write("Echo Request Bytes Sent (bytes),Echo Request Data Sent(bytes)\n")
        f.write(str(size_metrics[4]) + "," + str(size_metrics[6]) + "\n")
        f.write("Echo Request Bytes Recieived (bytes),Echo Request Data Received (bytes)\n")
        f.write(str(size_metrics[5]) + "," + str(size_metrics[7]) + "\n\n")

        f.write("Average RTT (milliseconds)," + str(time_metrics[0]) + "\n")
        f.write("Echo Request Throughput (kB/sec)," + str(time_metrics[1]) + "\n")
        f.write("Echo Request Goodput (kb/sec)," + str(time_metrics[2]) + "\n")
        f.write("Average Reply Delay (microseconds)," + str(time_metrics[3]) + "\n")
        f.write("Average Echo Request Hop Count," + str(distance_metric) + "\n\n")

    f.close()    
