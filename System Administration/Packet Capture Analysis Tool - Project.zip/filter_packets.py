#!/bin/python3
import os
import re

files = ["Node1", "Node2", "Node3", "Node4"]

def filter_files():
    for file in files:
        fName = file + ".txt"
        filtered = file + "_filtered.txt"
        if os.path.exists(filtered):
            os.remove(filtered)

        rf = open(fName, "r")
        wf = open(filtered, "a")

        unfiltered = rf.read()
        matches = re.findall(".+\n.+ICMP.+\n\n(?:.+\n)+", unfiltered, re.M)
       
        for match in matches:           
            wf.write(match + "\n")
        rf.close()
        wf.close()

def filter_data(fName, data):
    f = open(fName, "r")
    for line in f:
        if "ICMP" in line:
            data.append(line.strip().split())
