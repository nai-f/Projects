#!/bin/python3
from filter_packets import *
from packet_parser import *
from compute_metrics import *

import re
import sys

file1 = "Node1_filtered.txt"
file2 = "Node2_filtered.txt"
file3 = "Node3_filtered.txt"
file4 = "Node4_filtered.txt"

data1 = []
data2 = []
data3 = []
data4 = []

filter_files()

parse_data(file1, data1)
parse_data(file2, data2)
parse_data(file3, data3)
parse_data(file4, data4)

compute_metrics([data1,data2,data3,data4])

