#!/bin/python3

def parse_data(fName, data):
    f = open(fName, "r")
    for line in f:
        if "ICMP" in line:
            data.append(line.strip().split())
